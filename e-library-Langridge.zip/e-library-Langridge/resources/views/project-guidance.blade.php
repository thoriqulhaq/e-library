<h1>This is notes for set-up our project</h1>

<ul>
    <li>Install Composer</li>
    <li>Install NPM + Node</li>
    <li>Intall Git + Git Bash</li>
    <li>Clone Repository</li>
    <li>In your IDE's terminal type "composer install"</li>
    <li>add ".env" in your project directory</li>
    <li>Checkout to Dev (Only modify this branch. Don't use Master or Stage)</li>
    <li>Development / Code</li>
    <li>To run the server type "php artisan serve" in your terminal</li>
    <li>Push to Dev</li>

</ul>