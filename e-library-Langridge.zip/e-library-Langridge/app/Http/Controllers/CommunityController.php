<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AcademicResources;
use App\Models\Journals;
use App\Models\Author;
use DB;

class CommunityController extends Controller
{
    public function viewLandingPage()
    {
        return view('community.landingPage');
    }

    public function viewDetail(Request $request, $id)
    {
        $userid = 1;
        $academicResourceID = $id;

        $academicResource = DB::table('academic_resources')->where('id', $academicResourceID)->get();
        $bookmarkStatus = DB::table('academic_resources_public_users')->where('academic_resources_id', $academicResourceID)->where('users_id', $userid)->get();

        return view('community.details', [
            'academicResource' => current(current($academicResource)),
            'bookmarkStatus' => count(current($bookmarkStatus)),
        ]);
    } 

    public function viewLoginPage()
    {
        return view('community.login');
    }
    
    public function viewUploadJournal()
    {
        return view('community.uploadjournal');
    }
    public function saveJournalInfo(Request $request, AcademicResources $acadres, Journals $journal) {
        $acadres->title = $request->title;
        $acadres->description = $request->description;
        $acadres->genre = $request->genre;
        $acadres->publication_place = $request->input("publish-place");
        $acadres->publication_date = $request->input("publish-date");
        $acadres->type = 1;
        $acadres->file_path = $request->file("journal-file")->store("journal");

        $acadres->save();
        $journal->volume = $request->volume;
        $journal->issue = $request->issue;
        $acadres->details()->save($journal);
    }

    public function submitUploadJournal(Request $request) {
        $acadres = new AcademicResources();
        $journal = new Journals();
        
        $this->saveJournalInfo($request, $acadres, $journal);

        $authorsname = $request->author;
        if (!is_array($authorsname)) {
            $authorsname = [$authorsname];
        }
        foreach ($authorsname as $name) {
            echo $name;
            $author = Author::where("name", $name)->first();
            if ($author == null) {
                $author = new Author();
                $author->name = $name;
                $author->save();
            }
            $acadres->authors()->attach($name);
        }


    }

    public function editJournal(Request $request, $id) {
        $journal = AcademicResources::where("id", $id)->first();

        return view("community.editjournal", [ "title" => $journal->title,
                                        "genre" => $journal->genre,
                                        "description" => $journal->description,
                                        "publish_place" => $journal->publication_place, "publish_date" => $journal->publication_date]);
    }

    public function editJournalP(Request $request, $id) {
        $acadres = AcademicResources::where("id", $id)->first();

        $details = $acadres->details();
        $this->saveJournalInfo($request, $acadres, $details);
    }
}
