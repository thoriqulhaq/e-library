
<?php $__env->startSection('title', 'Upload New Journal'); ?>
<?php $__env->startSection('page'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="upload.css">
    <link rel="stylesheet" href="tester.css">
    <title>Upload Journal</title>

    <style>

header {
  border-bottom: 1px solid #ddd;
  padding-bottom: 10px;
  margin-bottom: 20px;
  display: flex;
}
h1 {
  flex: 1;
  padding: 0;
  margin: 0;
  font-size: 16px;
  letter-spacing: 1px;
  font-weight: 700;
  color: #7a7b7f;
}

.ways ul {
  display: flex;
  list-style: none;
  padding: 0;
  border-radius: 5px;
  overflow: hidden;
}
.ways li {
  align-self: center;
  flex: 1;
  background-color: #f5f7fa;
  text-align: center;
  cursor: pointer;
  padding: 15px 0;
  color: #999;
  text-transform: uppercase;
  font-weight: 500;
  font-size: 12px;
  letter-spacing: 1px;
  border: 1px solid #ddd;
}

.ways li:first-child {
  border-right: 0;
}
.ways li:last-child {
  border-left: 0;
}
.ways li.active {
  border: 2px 10px 20px 30px solid #1aa1e5;
  color: #66676c;
}
.ways li.active::before {
  content: "\f00c";
  font-family: "fontawesome";
  color: #1aa1e5;
}
.ways li:not(.active) {
  padding: 16px 0;
}
section {
  display: none;
}
section.active {
  display: block;
}
#ab1.active{
  display: block;
}
textarea {
  display: block;
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #ddd;
  outline: 0;
  background-color: #f5f7fa;
  padding: 10px;
  margin-bottom: 10px;
  letter-spacing: 1.4px;
  min-height: 200px;
}



.select-option {
  background-color: #f5f7fa;
  color: #999;
  font-size: 15px;
  position: relative;
  cursor: pointer;
}
.select-option::before {
  content: "\f107";
  font-family: "fontawesome";
  position: absolute;
  right: 0;
  top: 0;
  margin-top: 9px;
  margin-right: 10px;
  font-size: 20px;
}
.select-option div:not(.option) {
  padding: 10px 10px;
  border: 1px solid #ddd;
}
.select-option div:last-child,
.select-option .head {
  border-bottom: 1px solid #ddd;
}
.select-option .option {
  display: none;
}
.select-option .option div {
  text-transform: capitalize;
}
.select-option.active .option {
  display: block;
  position: absolute;
  width: 100%;
  background-color: #f5f7fa;
  box-sizing: border-box;
  padding: 0;
  margin-top: -1px;
  z-index: 2;
}
.select-option .option div {
  border-bottom: 0;
}
.images {
  display: flex;
  flex-wrap: wrap;
  margin-top: 20px;
}
.images .img,
.images .pic {
  flex-basis: 31%;
  margin-bottom: 10px;
  border-radius: 4px;
}
.images .img {
  width: 112px;
  height: 93px;
  background-size: cover;
  margin-right: 10px;
  background-position: center;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.images .img:nth-child(3n) {
  margin-right: 0;
}
.images .img span {
  display: none;
  text-transform: capitalize;
  z-index: 2;
}
.images .img::after {
  content: "";
  width: 100%;
  height: 100%;
  transition: opacity 0.1s ease-in;
  border-radius: 4px;
  opacity: 0;
  position: absolute;
}
.images .img:hover::after {
  display: block;
  background-color: #000;
  opacity: 0.5;
}
.images .img:hover span {
  display: block;
  color: #fff;
}
.images .pic {
  background-color: #f5f7fa;
  align-self: center;
  text-align: center;
  padding: 40px 0;
  text-transform: uppercase;
  color: #848ea1;
  font-size: 12px;
  cursor: pointer;
}

@media  screen and (max-width: 400px) {

  header {
    flex-direction: column;
  }
  header span {
    text-align: left;
    margin-top: 10px;
  }
  .ways li,
  section input,
  section textarea,
  .select-option .head,
  .select-option .option div {
    font-size: 8px;
  }
  .images .img,
  .images .pic {
    flex-basis: 100%;
    margin-right: 0;
  }
}

.notification {
  position: absolute;
  left: 20px;
  bottom: 20px;
  top: auto;
  right: auto;
}

.notification p {
  margin: 0;
  padding: 0;
}
.notification .btn {
  padding: 16px 20px;
  border-radius: 5px;
  display: flex;
  margin-bottom: 10px;
  font-size: 12px;
  align-items: center;
  animation: fadeIn 0.4s ease-in;
}
@keyframes  fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
.notification .btn::before {
  margin-right: 12px;
  font-family: "fontawesome";
  font-size: 15px;
}
.notification span {
  margin-left: 10px;
  cursor: pointer;
  flex: 1;
  text-align: right;
}

.notification .error {
  background-color: #ecc8c5;
  border: 1px solid #bd8181;
}
.notification .error span {
  color: #c79995;
}
.notification .error::before {
  content: "\f05c";
  color: #b2312f;
}
.notification .success {
  background-color: #def2d6;
  border: 1px solid #b3cea9;
}
.notification .success span {
  color: #afc7a7;
}
.notification .success::before {
  content: "\f00c";
  color: #5a7052;
}

footer {
  text-align: center;
  margin-bottom: 20px;
  text-transform: uppercase;
  letter-spacing: 2px;
  color: #fff;
  font-size: 12px;
}
footer a {
  color: #fff;
  text-decoration: none;
  border-bottom: 1px solid #fff;
  padding-bottom: 5px;
}

    </style>
    
  </head>
  <body>
    <div >
      <header>
        <h1>Upload your file</h1>
      </header>

      <ul class="nav nav-tabs mb-3">
        <li class="nav-item">
          <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#submit">Submit</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" data-bs-toggle="tab" data-bs-target="#about" >About</button>
        </li>
      </ul>
      <br>

      <form action="<?php echo e(url('/uploadjournal')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="tab-content">
          <div class="tab-pane fade show active" id="submit" ><!-- isi upload taruh didalam ini-->
            <div class="row">
              <h>Name of Author
              <input type="text" class="form-control" name="author[]" placeholder="Name of Author" id="name" required/>
              <h>Title</h>
              <input type="text" class="form-control" name="title" placeholder="Title" id="title" required/>
              <h>Genre</h>
              <input type="text" class="form-control" name="genre" placeholder="Genre" id="genre" />
              <h>Date</h>
              <input type="datetime" class="form-control" name="publish-place" placeholder="Date of Publication" id="date" required/>
              <br>
              <input type="text" class="form-control" name="publish-date" placeholder="Publication Place" id="place" required/>
              <br>
              <input type="number" class="form-control" name="volume" placeholder="Volume Number" id="volume"/>
              <br>
              <input type="number" class="form-control" name="issue"placeholder="Issue Number" id="issue"/>
              <br>
              <input type="number" class="form-control" name="type" placeholder="Type" id="type"/>
            </div>
            
            <div class="my-4"> <!-- ini margin y atau margin top dan margin bottom -->
              <input class="form-control" type="file" name="journal-file">
              
              <script class="jsbin" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
              <br>
            </div>
      
              
            <div class="row">
              <div class="col">
                <button style="width: 100%;"  type="reset" class="btn btn-outline-primary">Reset</button>
              </div>
              <div class="col">
                <button style="width: 100%;" type="submit" class="btn btn-primary" href="/">Submit</button>
              </div>
            </div>
          </div>
        <div class="tab-pane fade" id="about"><!-- isi about taruh didalam ini-->
          <div class="row" id="ab1">
            <textarea name="description" placeholder="Description..." id="msg"></textarea>
          </div>
        </div>
      </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" class="jsbin"></script>
    <script src="tester.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A S U S\Documents\html\Appdev project\e-library-Langridge\resources\views/community/uploadjournal.blade.php ENDPATH**/ ?>