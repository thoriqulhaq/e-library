<?php $__env->startSection('title', 'Bookmark'); ?>
<?php $__env->startSection('page'); ?>

              <div class="container position-relative mt-5" style="padding: 120px 0; ">
              <div class="text-center" style="height:100vh;">
                <h4 >Bookmark Collection<br></h4>
                
                
                
                  <table class="table table-borderedtext-center" style="">
                    <thead>
                      <tr class="">
                        <th>
                        </th>
                        
                        
                        <th style="width:50%"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $academicResource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <h>hi</h>
                      <tr>
                        <td >
                       <a  href="<?php echo e(url('/book/' . $datas->id)); ?>" style="color: inherit"> <?php echo e($datas->title); ?> </a>
                        <h> hi 1 </h>
                          
                      
                      </td>
                       <h>hi 2</h>
                        
                        <td >
                          <h>hi 3</h>
                          <a href=""
                          <a  href="<?php echo e(url('/delete-bookmark/' . $datas->id)); ?>" type="button" class="btn"data-toggle="tooltip" data-original-title="Delete">
                            <ion-icon size="large" name="trash"></ion-icon>
                          </a>
                        </td>
                      </tr>

                      
                      <h>hi 4</h>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <h>hi 5</h>
                <script>

                  

                </script>
              </div>
              
               
          <?php $__env->stopSection(); ?>   
            
<?php echo $__env->make('community.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A S U S\Documents\html\Appdev project\e-library-Langridge\resources\views/community/bookmarkList.blade.php ENDPATH**/ ?>